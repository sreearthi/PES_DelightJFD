package com.RestAssured;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }
    /*
     * URL-unique address used to make request(url,resource,query,path parameters)
     * http://reqres.in/api/users?page=2&total=12
     * Method
     * Headers
     * Body   100-199,200-299,300-399,
     */
}
