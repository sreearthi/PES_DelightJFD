package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentWithWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentWithWebApplication.class, args);
		System.out.println("Student Name : P.Siva");
		System.out.println("Standard : 10th");
		System.out.println("Parents Name : J.Parthiban , P.Parameshwari");
		System.out.println("Siblings : Nandhini , Shandhini ");
		System.out.println("Contact Number : 9884379477");
	}

}
