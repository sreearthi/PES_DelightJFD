package com.example.employeedemo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.employeedemo.entity.Employee;
import com.example.employeedemo.entity.EmployeeDTO;
import com.example.employeedemo.repository.EmployeeRepository;

@Service("employeeService")
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeRepository employeeRepository;
	
	@Override
	public String addEmployee(EmployeeDTO dto) {
		Optional<Employee> optional= employeeRepository.findByEmployeeEmail(dto.getEmployeeEmail());
		if(optional.isPresent())
			return "Employee already exists";
		else {
			Employee employee= new Employee();
			employee.setEmployeeName(dto.getEmployeeName());
			employee.setEmployeeEmail(dto.getEmployeeEmail());
			employee.setUsername(dto.getUsername());
			employee.setPassword(dto.getPassword());
			employee.setCategory(dto.getCategory());
			employee.setLocation(dto.getLocation());
			employeeRepository.save(employee);
			return "Employee added successfully";
		}
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		try {
			Iterable<Employee> players = employeeRepository.findAll();
			List<EmployeeDTO> list = new ArrayList<EmployeeDTO>();
			players.forEach(employee -> {
				EmployeeDTO dto = new EmployeeDTO();
				dto.setId(employee.getId());
				dto.setEmployeeName(employee.getEmployeeName());
				dto.setEmployeeEmail(employee.getEmployeeEmail());
				dto.setUsername(employee.getUsername());
				dto.setPassword(employee.getPassword());
				dto.setCategory(employee.getCategory());
				dto.setLocation(employee.getLocation());
				list.add(dto);
			});
			return list;
		}catch (Exception e) {
			throw e;
		}
	}

	@Override
	public EmployeeDTO getEmployeeById(Integer id) {
		try {
			Optional<Employee> optional= employeeRepository.findById(id);
			Employee employee=optional.get();
			EmployeeDTO dto = new EmployeeDTO();
			dto.setId(employee.getId());
			dto.setEmployeeName(employee.getEmployeeName());
			dto.setEmployeeEmail(employee.getEmployeeEmail());
			dto.setUsername(employee.getUsername());
			dto.setPassword(employee.getPassword());
			dto.setCategory(employee.getCategory());
			dto.setLocation(employee.getLocation());
			return dto;
			
		}catch (Exception e) {
			throw e;
		}
	}

	@Override
	public String updateEmployeeDetails(Integer id, EmployeeDTO dto) {
		Optional<Employee> optional= employeeRepository.findById(id);
		if(optional.isEmpty())
			return "Employee does not exists";
		Employee employee= optional.get();
		employee.setEmployeeEmail(dto.getEmployeeEmail());
		employee.setUsername(dto.getUsername());
		employee.setCategory(dto.getCategory());
		employee.setLocation(dto.getLocation());
		employeeRepository.save(employee);
		return "Employee details updated successfully";		
	}

	@Override
	public String deleteEmployee(Integer id) {
		Optional<Employee> optional= employeeRepository.findById(id);
		if(optional.isEmpty())
			return "Employee does not exists";
		Employee employee= optional.get();
		employeeRepository.delete(employee);
		return "Employee details deleted successfully";		
	}
	
}
