package com.example.employeedemo.repository;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import com.example.employeedemo.entity.Employee;

public interface EmployeeRepository extends CrudRepository<Employee, Integer>{
	Optional<Employee> findByEmployeeEmail(String employeeEmail);

}
