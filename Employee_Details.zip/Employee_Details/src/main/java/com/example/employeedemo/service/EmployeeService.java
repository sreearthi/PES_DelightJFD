package com.example.employeedemo.service;

import java.util.List;

import com.example.employeedemo.entity.EmployeeDTO;
public interface EmployeeService {
	public String addEmployee(EmployeeDTO employee);
	public List<EmployeeDTO> getAllEmployees();
	public EmployeeDTO getEmployeeById(Integer id);
	public String updateEmployeeDetails(Integer id, EmployeeDTO dto);
	public String deleteEmployee(Integer id);
}
