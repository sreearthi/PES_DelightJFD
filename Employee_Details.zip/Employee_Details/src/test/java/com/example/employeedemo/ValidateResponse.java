package com.example.employeedemo;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.Matchers.lessThan;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.simple.JSONObject;


@SuppressWarnings("unchecked")
public class ValidateResponse {
	
	private static final Log LOGGER= LogFactory.getLog(ValidateResponse.class);
	
	@BeforeClass
	 public  void setup() {
		RestAssured.baseURI = "http://localhost:8080/employee";
    }
	@Test
	public void ListOfEmployees() {
		RestAssured.given().contentType(ContentType.JSON).when().get("/listemployee").then().log().all().
		assertThat().statusCode(200).time(lessThan(5000l)).header("content-type", "application/json");
	}
	
	@Test
	public void listOfAEmployee() {
		RestAssured.given().
        contentType(ContentType.JSON).pathParams("id","1").when().get("/employee/{id}").then().assertThat().log().all().statusCode(200).
        body("id", equalTo(1)).body("employeeName", equalTo("Sachin Tendulkar")).body("employeeEmail", equalTo("sachin23@gmail.com")).
        body("username", equalTo("tendulkar43")).body("password", equalTo("asdnlnwq")).body("category", equalTo("football")).body("location", equalTo("USA"));
	}
	
	@Test
	public void addEmployee() {
		JSONObject jsp= new JSONObject();
		jsp.put("employeeName", "Cristiano Ronaldo");
		jsp.put("employeeEmail", "siuuuuu87@gmail.com");
		jsp.put("username", "ronaldo98");
		jsp.put("password", "abcxyz");
		jsp.put("category", "football");
		jsp.put("location", "Portugal");

		Response response= RestAssured.given().contentType(ContentType.JSON).body(jsp.toJSONString()).
		when().post("/register").then().assertThat().statusCode(200).extract().response();
		LOGGER.info(response.asString());
	}
	
	@Test
	public void updateEmployee() {
		JSONObject jsp= new JSONObject();
		jsp.put("employeeEmail", "tendulkar098@gmail.com");
		jsp.put("username", "sachin.tendulkar");
		jsp.put("category", "Football");
		jsp.put("location", "Africa");
		
		RestAssured.given().contentType(ContentType.JSON).body(jsp.toJSONString()).
		when().pathParams("id", "4").put("/updateEmployee/{id}").then().log().all().assertThat().statusCode(200);
	}
	
	@Test
	public void deleteEmployee() {
		RestAssured.given().contentType(ContentType.JSON).when().pathParam("id", "4").delete("/delete/{id}").
		then().log().all().assertThat().statusCode(200);
	}
}
